/*
 * main.cpp
 *
 *  Created on: 2021?2?20?
 *      Author: lenovo1
 */

#include <system.h>


//LEDS_BASE 0x9000
//SWITCHES_BASE 0x9010

int main(void){
	volatile int * LED_ptr = (int *)LEDS_BASE;//LED address
	volatile int * sw_ptr = (int *)SWITCHES_BASE;//switch address
	while(true){
		* LED_ptr = * sw_ptr;
	}

	return 0;
}
